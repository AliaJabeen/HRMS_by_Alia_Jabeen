
<?php
error_reporting(0);
$con=mysql_pconnect("localhost","root","");
mysql_select_db("HRMS",$con);

?>
