<footer class="container-fluid text-center">
  <p>&#169;Copyright 2020. All rights reserved</p>
</footer>

</body>
</html>